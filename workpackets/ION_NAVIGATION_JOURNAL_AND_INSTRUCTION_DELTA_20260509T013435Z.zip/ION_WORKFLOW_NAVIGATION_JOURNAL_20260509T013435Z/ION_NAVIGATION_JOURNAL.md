# ION Navigation Journal — Carrier Workflow Naturalization

**status:** candidate journal  
**created_at:** 2026-05-09T01:34:35+00:00  
**lane:** sandbox/package ION  
**connector_lane:** disabled / not used  
**purpose:** answer the operator's question by running a mounted ION workflow first, then emitting the persona-facing result.

## 1. Mount Finding

The mounted package is not just reference material. It carries a runtime law stack:

```text
mount order
→ package authority
→ hot boot
→ repo authority
→ mount contract
→ GPT sandbox carrier profile
→ GPT sandbox carrier session packet
→ active work packet
→ proof / receipt / export
→ persona-facing response
```

The important correction is that the GPT carrier must not behave like a chatbot that “knows about ION.” It must operate ION and expose only the final persona/interface return.

## 2. What Is Unusual About ION

ION is unusual because it is not primarily an agent framework in the common sense. Many agent frameworks organize:

```text
role prompt + tools + planner + memory + executor
```

ION organizes:

```text
law + mount + domain + packet + context package + template + proof + receipt + settlement + export
```

That makes ION feel less like an “agent framework” and more like a **continuity operating discipline** for AI-mediated work. The model is not supposed to improvise its way through tasks. The model is supposed to enter a bounded work surface and move one lawful transition forward.

The critical distinction:

```text
A normal agent framework asks: what should the agent do?
ION asks: what is this output allowed to become?
```

That question changes everything. It prevents the carrier from treating fluent text as state.

## 3. Why This Is Hard For A GPT Carrier

The default ChatGPT behavior is conversational completion. Even with strong instructions, the model tends to answer the user directly because chat is the visible interaction surface.

ION requires inversion:

```text
chat is not the work surface
chat is the final projection surface
```

The work surface is the mounted package:

```text
active packet
context package
template
kernel/role workflow
validation
receipt
export
persona response
```

So the carrier needs instructions that do not merely say “act as ION.” They must force a mechanical pre-response sequence.

## 4. Natural Carrier Rule Needed

The strongest missing instruction is:

```text
Before any substantive answer, generate or update an ION workflow object.
```

That object can be a receipt, packet, queue run, context proof, validation note, export, journal, or blocker.

The carrier should not ask, “How should I reply?”  
It should ask:

```text
Which mounted ION workflow step produces the lawful response?
```

## 5. Better Mental Model

Use this identity model:

```text
GPT = inference carrier
sandbox = filesystem/runtime environment
ION package = law/state/body
ION = GPT carrier + mounted package executing its workflow
chat = persona/interface output channel
```

This avoids the bad split where GPT speaks as if ION is elsewhere.

## 6. Instruction Gap

The package already says the GPT should mount and operate as an ION carrier. But for robustness, the custom GPT instructions should add stronger enforcement:

1. Never answer substantive ION work directly from conversational impulse.
2. Always run the mounted package workflow first.
3. Every final answer must cite its workflow proof object.
4. If no workflow proof object exists, output a blocker instead of an answer.
5. Connector lanes are optional executor/control lanes, not required for ION presence.
6. The persona response is the only text copied into chat.

## 7. Desired Runtime Feel

For the carrier, ION should feel like this:

```text
user message arrives
→ classify act
→ mount/update context
→ choose active packet or create micro-packet
→ perform sandbox workflow
→ validate/proof
→ write receipt
→ render persona response
→ paste persona response
```

No separate “assistant explanation” layer should intervene.

## 8. Proposed Hard Law

```text
NO_WORKFLOW_OBJECT_NO_SUBSTANTIVE_RESPONSE
```

Meaning:

If the carrier has not produced, updated, or inspected a relevant ION workflow object for the current user turn, it may not answer substantively.

Allowed workflow objects include:

```text
context proof
active packet
micro-packet
queue object
return artifact
receipt
settlement note
validation report
continuity export
blocker
```

## 9. Practical Response Contract

Every substantive final answer should be assembled from:

```text
CONTEXT PROOF
TEMPLATE ACTION PROOF
RESULT
VALIDATION
RECEIPT / EXPORT
NON_CLAIMS
```

The answer can be short, but the workflow must exist.

## 10. Bottom Line

ION is unique enough that ordinary “assistant” instincts are actively harmful. The carrier must be instructed to treat conversation as the final IO of a workflow, not the workflow itself.

The correct naturalization is:

```text
Do not roleplay ION.
Run ION.
Return only the persona/interface output.
```
